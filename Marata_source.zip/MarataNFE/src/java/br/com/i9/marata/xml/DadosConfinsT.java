/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.xml;

/**
 *
 * @author geoleite
 */
public class DadosConfinsT {
    private String cst;
    private String vbc;
    private String pcofins;
    private String vcofins;

    /**
     * @return the cst
     */
    public String getCst() {
        return cst;
    }

    /**
     * @param cst the cst to set
     */
    public void setCst(String cst) {
        this.cst = cst;
    }

    /**
     * @return the vbc
     */
    public String getVbc() {
        return vbc;
    }

    /**
     * @param vbc the vbc to set
     */
    public void setVbc(String vbc) {
        this.vbc = vbc;
    }

    /**
     * @return the pcofins
     */
    public String getPcofins() {
        return pcofins;
    }

    /**
     * @param pcofins the pcofins to set
     */
    public void setPcofins(String pcofins) {
        this.pcofins = pcofins;
    }

    /**
     * @return the vcofins
     */
    public String getVcofins() {
        return vcofins;
    }

    /**
     * @param vcofins the vcofins to set
     */
    public void setVcofins(String vcofins) {
        this.vcofins = vcofins;
    }
}
