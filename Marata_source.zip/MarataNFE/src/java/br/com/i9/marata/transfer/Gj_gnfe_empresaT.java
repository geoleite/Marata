package br.com.i9.marata.transfer;

import br.com.easynet.annotation.Conversion;
//br.com.i9.marata.transfer.Gj_gnfe_empresaT
public class Gj_gnfe_empresaT { 
	 private String cod_empresa;
	 private String cnpj_empresa;
	 private String den_empresa;
	 private String id_ent;
	 public void setCod_empresa(String cod_empresa) {
		 this.cod_empresa=cod_empresa;
	}
 
	 public String getCod_empresa() {
		 return cod_empresa;
 	} 
 	 public void setCnpj_empresa(String cnpj_empresa) {
		 this.cnpj_empresa=cnpj_empresa;
	}
 
	 public String getCnpj_empresa() {
		 return cnpj_empresa;
 	} 
 	 public void setDen_empresa(String den_empresa) {
		 this.den_empresa=den_empresa;
	}
 
	 public String getDen_empresa() {
		 return den_empresa;
 	} 
 	 public void setId_ent(String id_ent) {
		 this.id_ent=id_ent;
	}
 
	 public String getId_ent() {
		 return id_ent;
 	} 
 }