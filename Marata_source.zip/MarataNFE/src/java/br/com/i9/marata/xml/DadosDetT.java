/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.xml;

/**
 *
 * @author geoleite
 */
public class DadosDetT {
    private DadosProdT dadosProdT;
    private DadosImpostoT dadosImpostoT;

    /**
     * @return the dadosProdT
     */
    public DadosProdT getDadosProdT() {
        return dadosProdT;
    }

    /**
     * @param dadosProdT the dadosProdT to set
     */
    public void setDadosProdT(DadosProdT dadosProdT) {
        this.dadosProdT = dadosProdT;
    }

    /**
     * @return the dadosImpostoT
     */
    public DadosImpostoT getDadosImpostoT() {
        return dadosImpostoT;
    }

    /**
     * @param dadosImpostoT the dadosImpostoT to set
     */
    public void setDadosImpostoT(DadosImpostoT dadosImpostoT) {
        this.dadosImpostoT = dadosImpostoT;
    }
    
}
