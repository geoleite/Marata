/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.i9.marata.xml;

/**
 *
 * @author Marcelo
 */
public class DadosFatT {
    private String nfat;
    private String vorig;
    private String vliq;

    /**
     * @return the nfat
     */
    public String getNfat() {
        return nfat;
    }

    /**
     * @param nfat the nfat to set
     */
    public void setNfat(String nfat) {
        this.nfat = nfat;
    }

    /**
     * @return the vorig
     */
    public String getVorig() {
        return vorig;
    }

    /**
     * @param vorig the vorig to set
     */
    public void setVorig(String vorig) {
        this.vorig = vorig;
    }

    /**
     * @return the vliq
     */
    public String getVliq() {
        return vliq;
    }

    /**
     * @param vliq the vliq to set
     */
    public void setVliq(String vliq) {
        this.vliq = vliq;
    }
    
    
}
