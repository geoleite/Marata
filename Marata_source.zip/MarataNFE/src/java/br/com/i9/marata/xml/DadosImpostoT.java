/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.xml;

/**
 *
 * @author geoleite
 */
public class DadosImpostoT {
    private DadosICMST dadosICMST;
    private DadosPisT dadosPisT;
    private DadosConfinsT dadosConfinsT;

    /**
     * @return the dadosICMST
     */
    public DadosICMST getDadosICMST() {
        return dadosICMST;
    }

    /**
     * @param dadosICMST the dadosICMST to set
     */
    public void setDadosICMST(DadosICMST dadosICMST) {
        this.dadosICMST = dadosICMST;
    }

    /**
     * @return the dadosPisT
     */
    public DadosPisT getDadosPisT() {
        return dadosPisT;
    }

    /**
     * @param dadosPisT the dadosPisT to set
     */
    public void setDadosPisT(DadosPisT dadosPisT) {
        this.dadosPisT = dadosPisT;
    }

    /**
     * @return the dadosConfinsT
     */
    public DadosConfinsT getDadosConfinsT() {
        return dadosConfinsT;
    }

    /**
     * @param dadosConfinsT the dadosConfinsT to set
     */
    public void setDadosConfinsT(DadosConfinsT dadosConfinsT) {
        this.dadosConfinsT = dadosConfinsT;
    }
}
