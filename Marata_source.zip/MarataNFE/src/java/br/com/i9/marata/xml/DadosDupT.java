/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.i9.marata.xml;

/**
 *
 * @author Marcelo
 */
public class DadosDupT {

    private String ndup;
    private String dvenc;
    private String vdup;

    /**
     * @return the ndup
     */
    public String getNdup() {
        return ndup;
    }

    /**
     * @param ndup the ndup to set
     */
    public void setNdup(String ndup) {
        this.ndup = ndup;
    }

    /**
     * @return the dvenc
     */
    public String getDvenc() {
        return dvenc;
    }

    /**
     * @param dvenc the dvenc to set
     */
    public void setDvenc(String dvenc) {
        this.dvenc = dvenc;
    }

    /**
     * @return the vdup
     */
    public String getVdup() {
        return vdup;
    }

    /**
     * @param vdup the vdup to set
     */
    public void setVdup(String vdup) {
        this.vdup = vdup;
    }
}
