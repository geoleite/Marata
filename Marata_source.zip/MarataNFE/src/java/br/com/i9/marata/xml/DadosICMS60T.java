/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.xml;

/**
 *
 * @author geoleite
 */
public class DadosICMS60T {
    private String orig ;
    private String cst;
    private String vbcst;
    private String vicmsst;

    /**
     * @return the orig
     */
    public String getOrig() {
        return orig;
    }

    /**
     * @param orig the orig to set
     */
    public void setOrig(String orig) {
        this.orig = orig;
    }

    /**
     * @return the cst
     */
    public String getCst() {
        return cst;
    }

    /**
     * @param cst the cst to set
     */
    public void setCst(String cst) {
        this.cst = cst;
    }

    /**
     * @return the vbcst
     */
    public String getVbcst() {
        return vbcst;
    }

    /**
     * @param vbcst the vbcst to set
     */
    public void setVbcst(String vbcst) {
        this.vbcst = vbcst;
    }

    /**
     * @return the vicmsst
     */
    public String getVicmsst() {
        return vicmsst;
    }

    /**
     * @param vicmsst the vicmsst to set
     */
    public void setVicmsst(String vicmsst) {
        this.vicmsst = vicmsst;
    }
    

}
