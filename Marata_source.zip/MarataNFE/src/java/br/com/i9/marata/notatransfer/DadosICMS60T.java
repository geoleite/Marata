/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.notatransfer;

/**
 *
 * @author geoleite
 */
public class DadosICMS60T {

}
