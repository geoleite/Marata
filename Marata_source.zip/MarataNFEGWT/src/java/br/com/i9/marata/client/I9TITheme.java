/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.client;

import com.extjs.gxt.ui.client.util.Theme;

/**
 *
 * @author geoleite
 */
public class I9TITheme extends Theme {

  public static Theme I9TI = new I9TITheme();

  public I9TITheme() {
    super("I9TI", "I9TI", "gxt/themes/i9ti/css/i9ti.css");
  }

  public I9TITheme(String name) {
    super("i9ti", name, "gxt/themes/i9ti/css/i9ti.css");
  }
}
