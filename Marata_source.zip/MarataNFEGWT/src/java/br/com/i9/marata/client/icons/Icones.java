/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.client.icons;

import com.google.gwt.core.client.GWT;

/**
 *
 * @author geoleite
 */
public class Icones {
    public final static IconsNFE ICONS = GWT.create(IconsNFE.class);
}
