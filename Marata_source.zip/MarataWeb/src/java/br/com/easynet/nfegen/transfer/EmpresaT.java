/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.easynet.nfegen.transfer;

/**
 *
 * @author geoleite
 */
public class EmpresaT {

    private String codEmpresa;
    private String cnpjEmpresa;
    private String denEmpresa;
    private String idEnt;

    /**
     * @return the codEmpresa
     */
    public String getCodEmpresa() {
        return codEmpresa;
    }

    /**
     * @param codEmpresa the codEmpresa to set
     */
    public void setCodEmpresa(String codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    /**
     * @return the cnpjEmpresa
     */
    public String getCnpjEmpresa() {
        return cnpjEmpresa;
    }

    /**
     * @param cnpjEmpresa the cnpjEmpresa to set
     */
    public void setCnpjEmpresa(String cnpjEmpresa) {
        this.cnpjEmpresa = cnpjEmpresa;
    }

    /**
     * @return the denEmpresa
     */
    public String getDenEmpresa() {
        return denEmpresa;
    }

    /**
     * @param denEmpresa the denEmpresa to set
     */
    public void setDenEmpresa(String denEmpresa) {
        this.denEmpresa = denEmpresa;
    }

    /**
     * @return the idEnt
     */
    public String getIdEnt() {
        return idEnt;
    }

    /**
     * @param idEnt the idEnt to set
     */
    public void setIdEnt(String idEnt) {
        this.idEnt = idEnt;
    }
}
