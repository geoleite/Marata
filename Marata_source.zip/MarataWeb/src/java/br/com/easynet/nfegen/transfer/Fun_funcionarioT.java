package br.com.easynet.nfegen.transfer;

import br.com.easynet.annotation.Conversion;

public class Fun_funcionarioT { 
	 private int fun_nr_id;
	 private int dis_nr_id;
	 public void setFun_nr_id(int fun_nr_id) {
		 this.fun_nr_id=fun_nr_id;
	}
 
	 public int getFun_nr_id() {
		 return fun_nr_id;
 	} 
 	 public void setDis_nr_id(int dis_nr_id) {
		 this.dis_nr_id=dis_nr_id;
	}
 
	 public int getDis_nr_id() {
		 return dis_nr_id;
 	} 
 }