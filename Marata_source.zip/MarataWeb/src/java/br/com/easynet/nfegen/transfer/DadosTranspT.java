/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.easynet.nfegen.transfer;

/**
 *
 * @author geoleite
 */
public class DadosTranspT {
    private String modfrete;
    private String vol;
    private String veictransp;
    private String Transporta;
    /**
     * @return the modfrete
     */
    public String getModfrete() {
        return modfrete;
    }

    /**
     * @param modfrete the modfrete to set
     */
    public void setModfrete(String modfrete) {
        this.modfrete = modfrete;
    }

    /**
     * @return the vol
     */
    public String getVol() {
        return vol;
    }

    /**
     * @param vol the vol to set
     */
    public void setVol(String vol) {
        this.vol = vol;
    }

    /**
     * @return the veictransp
     */
    public String getVeictransp() {
        return veictransp;
    }

    /**
     * @param veictransp the veictransp to set
     */
    public void setVeictransp(String veictransp) {
        this.veictransp = veictransp;
    }

    /**
     * @return the Transporta
     */
    public String getTransporta() {
        return Transporta;
    }

    /**
     * @param Transporta the Transporta to set
     */
    public void setTransporta(String Transporta) {
        this.Transporta = Transporta;
    }

   
}
