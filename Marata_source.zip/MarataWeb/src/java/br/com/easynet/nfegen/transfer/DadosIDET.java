/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.easynet.nfegen.transfer;

/**
 *
 * @author geoleite
 */
public class DadosIDET {
    private String cuf;
    private String cnf;
    private String natop;
    private String indpag;
    private String mod;
    private String serie;
    private String nnf;
    private String demi;
    private String dsaient;
    private String tpnf;
    private String cmunfg;
    private String tpimp;
    private String tpemis;
    private String cdv;
    private String tpamb;
    private String finnfe;
    private String procemi;
    private String verproc;
    

    /**
     * @return the cuf
     */
    public String getCuf() {
        return cuf;
    }

    /**
     * @param cuf the cuf to set
     */
    public void setCuf(String cuf) {
        this.cuf = cuf;
    }

    /**
     * @return the cnf
     */
    public String getCnf() {
        return cnf;
    }

    /**
     * @param cnf the cnf to set
     */
    public void setCnf(String cnf) {
        this.cnf = cnf;
    }

    /**
     * @return the natop
     */
    public String getNatop() {
        return natop;
    }

    /**
     * @param natop the natop to set
     */
    public void setNatop(String natop) {
        this.natop = natop;
    }

    /**
     * @return the indpag
     */
    public String getIndpag() {
        return indpag;
    }

    /**
     * @param indpag the indpag to set
     */
    public void setIndpag(String indpag) {
        this.indpag = indpag;
    }

    /**
     * @return the mod
     */
    public String getMod() {
        return mod;
    }

    /**
     * @param mod the mod to set
     */
    public void setMod(String mod) {
        this.mod = mod;
    }

    /**
     * @return the serie
     */
    public String getSerie() {
        return serie;
    }

    /**
     * @param serie the serie to set
     */
    public void setSerie(String serie) {
        this.serie = serie;
    }

    /**
     * @return the nnf
     */
    public String getNnf() {
        return nnf;
    }

    /**
     * @param nnf the nnf to set
     */
    public void setNnf(String nnf) {
        this.nnf = nnf;
    }

    /**
     * @return the demi
     */
    public String getDemi() {
        return demi;
    }

    /**
     * @param demi the demi to set
     */
    public void setDemi(String demi) {
        this.demi = demi;
    }

    /**
     * @return the dsaient
     */
    public String getDsaient() {
        return dsaient;
    }

    /**
     * @param dsaient the dsaient to set
     */
    public void setDsaient(String dsaient) {
        this.dsaient = dsaient;
    }

    /**
     * @return the tpnf
     */
    public String getTpnf() {
        return tpnf;
    }

    /**
     * @param tpnf the tpnf to set
     */
    public void setTpnf(String tpnf) {
        this.tpnf = tpnf;
    }

    /**
     * @return the cmunfg
     */
    public String getCmunfg() {
        return cmunfg;
    }

    /**
     * @param cmunfg the cmunfg to set
     */
    public void setCmunfg(String cmunfg) {
        this.cmunfg = cmunfg;
    }

    /**
     * @return the tpimp
     */
    public String getTpimp() {
        return tpimp;
    }

    /**
     * @param tpimp the tpimp to set
     */
    public void setTpimp(String tpimp) {
        this.tpimp = tpimp;
    }

    /**
     * @return the tpemis
     */
    public String getTpemis() {
        return tpemis;
    }

    /**
     * @param tpemis the tpemis to set
     */
    public void setTpemis(String tpemis) {
        this.tpemis = tpemis;
    }

    /**
     * @return the cdv
     */
    public String getCdv() {
        return cdv;
    }

    /**
     * @param cdv the cdv to set
     */
    public void setCdv(String cdv) {
        this.cdv = cdv;
    }

    /**
     * @return the tpamb
     */
    public String getTpamb() {
        return tpamb;
    }

    /**
     * @param tpamb the tpamb to set
     */
    public void setTpamb(String tpamb) {
        this.tpamb = tpamb;
    }

    /**
     * @return the finnfe
     */
    public String getFinnfe() {
        return finnfe;
    }

    /**
     * @param finnfe the finnfe to set
     */
    public void setFinnfe(String finnfe) {
        this.finnfe = finnfe;
    }

    /**
     * @return the procemi
     */
    public String getProcemi() {
        return procemi;
    }

    /**
     * @param procemi the procemi to set
     */
    public void setProcemi(String procemi) {
        this.procemi = procemi;
    }

    /**
     * @return the verproc
     */
    public String getVerproc() {
        return verproc;
    }

    /**
     * @param verproc the verproc to set
     */
    public void setVerproc(String verproc) {
        this.verproc = verproc;
    }

    
}
