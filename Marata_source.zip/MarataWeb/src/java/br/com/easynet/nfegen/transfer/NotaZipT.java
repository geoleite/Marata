/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.easynet.nfegen.transfer;

/**
 *
 * @author geoleite
 */
public class NotaZipT {
    private Not_notaT not_notaT;
    private String msg;

    /**
     * @return the not_notaT
     */
    public Not_notaT getNot_notaT() {
        return not_notaT;
    }

    /**
     * @param not_notaT the not_notaT to set
     */
    public void setNot_notaT(Not_notaT not_notaT) {
        this.not_notaT = not_notaT;
    }

    /**
     * @return the msg
     */
    public String getMsg() {
        return msg;
    }

    /**
     * @param msg the msg to set
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }

}
