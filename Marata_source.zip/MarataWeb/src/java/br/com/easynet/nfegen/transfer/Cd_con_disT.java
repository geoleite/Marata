package br.com.easynet.nfegen.transfer;

import br.com.easynet.annotation.Conversion;

public class Cd_con_disT { 
	 private int con_nr_id;
	 private int dis_nr_id;
	 public void setCon_nr_id(int con_nr_id) {
		 this.con_nr_id=con_nr_id;
	}
 
	 public int getCon_nr_id() {
		 return con_nr_id;
 	} 
 	 public void setDis_nr_id(int dis_nr_id) {
		 this.dis_nr_id=dis_nr_id;
	}
 
	 public int getDis_nr_id() {
		 return dis_nr_id;
 	} 
 }