package br.com.easynet.nfegen.transfer;

import br.com.easynet.annotation.Conversion;

public class De_dis_empT { 
	 private int dis_nr_id;
	 private int emp_nr_id;
	 public void setDis_nr_id(int dis_nr_id) {
		 this.dis_nr_id=dis_nr_id;
	}
 
	 public int getDis_nr_id() {
		 return dis_nr_id;
 	} 
 	 public void setEmp_nr_id(int emp_nr_id) {
		 this.emp_nr_id=emp_nr_id;
	}
 
	 public int getEmp_nr_id() {
		 return emp_nr_id;
 	} 
 }