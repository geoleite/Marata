/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.notatransfer;

/**
 *
 * @author geoleite
 */
public class DadosTotalT {
    private String vbc;
    private String vicms;
    private String vbcst;
    private String vst;
    private String vprod;
    private String vfrete;
    private String vseg;
    private String vdesc;
    private String vii;
    private String vipi;
    private String vpis;
    private String vcofins;
    private String voutro;
    private String vnf;

    /**
     * @return the vbc
     */
    public String getVbc() {
        return vbc;
    }

    /**
     * @param vbc the vbc to set
     */
    public void setVbc(String vbc) {
        this.vbc = vbc;
    }

    /**
     * @return the vicms
     */
    public String getVicms() {
        return vicms;
    }

    /**
     * @param vicms the vicms to set
     */
    public void setVicms(String vicms) {
        this.vicms = vicms;
    }

    /**
     * @return the vbcst
     */
    public String getVbcst() {
        return vbcst;
    }

    /**
     * @param vbcst the vbcst to set
     */
    public void setVbcst(String vbcst) {
        this.vbcst = vbcst;
    }

    /**
     * @return the vst
     */
    public String getVst() {
        return vst;
    }

    /**
     * @param vst the vst to set
     */
    public void setVst(String vst) {
        this.vst = vst;
    }

    /**
     * @return the vprod
     */
    public String getVprod() {
        return vprod;
    }

    /**
     * @param vprod the vprod to set
     */
    public void setVprod(String vprod) {
        this.vprod = vprod;
    }

    /**
     * @return the vfrete
     */
    public String getVfrete() {
        return vfrete;
    }

    /**
     * @param vfrete the vfrete to set
     */
    public void setVfrete(String vfrete) {
        this.vfrete = vfrete;
    }

    /**
     * @return the vseg
     */
    public String getVseg() {
        return vseg;
    }

    /**
     * @param vseg the vseg to set
     */
    public void setVseg(String vseg) {
        this.vseg = vseg;
    }

    /**
     * @return the vdesc
     */
    public String getVdesc() {
        return vdesc;
    }

    /**
     * @param vdesc the vdesc to set
     */
    public void setVdesc(String vdesc) {
        this.vdesc = vdesc;
    }

    /**
     * @return the vii
     */
    public String getVii() {
        return vii;
    }

    /**
     * @param vii the vii to set
     */
    public void setVii(String vii) {
        this.vii = vii;
    }

    /**
     * @return the vipi
     */
    public String getVipi() {
        return vipi;
    }

    /**
     * @param vipi the vipi to set
     */
    public void setVipi(String vipi) {
        this.vipi = vipi;
    }

    /**
     * @return the vpis
     */
    public String getVpis() {
        return vpis;
    }

    /**
     * @param vpis the vpis to set
     */
    public void setVpis(String vpis) {
        this.vpis = vpis;
    }

    /**
     * @return the vcofins
     */
    public String getVcofins() {
        return vcofins;
    }

    /**
     * @param vcofins the vcofins to set
     */
    public void setVcofins(String vcofins) {
        this.vcofins = vcofins;
    }

    /**
     * @return the voutro
     */
    public String getVoutro() {
        return voutro;
    }

    /**
     * @param voutro the voutro to set
     */
    public void setVoutro(String voutro) {
        this.voutro = voutro;
    }

    /**
     * @return the vnf
     */
    public String getVnf() {
        return vnf;
    }

    /**
     * @param vnf the vnf to set
     */
    public void setVnf(String vnf) {
        this.vnf = vnf;
    }
    
}
