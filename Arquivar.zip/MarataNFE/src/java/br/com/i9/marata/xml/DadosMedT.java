/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.xml;

/**
 *
 * @author geoleite
 */
public class DadosMedT {
    private String nlote;
    private String qlote;
    private String dfab;
    private String dval;
    private String vpmc;

    /**
     * @return the nlote
     */
    public String getNlote() {
        return nlote;
    }

    /**
     * @param nlote the nlote to set
     */
    public void setNlote(String nlote) {
        this.nlote = nlote;
    }

    /**
     * @return the qlote
     */
    public String getQlote() {
        return qlote;
    }

    /**
     * @param qlote the qlote to set
     */
    public void setQlote(String qlote) {
        this.qlote = qlote;
    }

    /**
     * @return the dfab
     */
    public String getDfab() {
        return dfab;
    }

    /**
     * @param dfab the dfab to set
     */
    public void setDfab(String dfab) {
        this.dfab = dfab;
    }

    /**
     * @return the dval
     */
    public String getDval() {
        return dval;
    }

    /**
     * @param dval the dval to set
     */
    public void setDval(String dval) {
        this.dval = dval;
    }

    /**
     * @return the vpmc
     */
    public String getVpmc() {
        return vpmc;
    }

    /**
     * @param vpmc the vpmc to set
     */
    public void setVpmc(String vpmc) {
        this.vpmc = vpmc;
    }
}
