/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.xml;

/**
 *
 * @author geoleite
 */
public class DadosProdT {
    private String cprod;
    private String cean;
    private String xprod;
    private String ncm;
    private String genero;
    private String cfop;
    private String ucom;
    private String qcom;
    private String vuncom;
    private String vprod;
    private String ceantrib;
    private String utrib;
    private String qtrib;
    private String vuntrib;
    private DadosMedT dadosMedT;

    /**
     * @return the cprod
     */
    public String getCprod() {
        return cprod;
    }

    /**
     * @param cprod the cprod to set
     */
    public void setCprod(String cprod) {
        this.cprod = cprod;
    }

    /**
     * @return the cean
     */
    public String getCean() {
        return cean;
    }

    /**
     * @param cean the cean to set
     */
    public void setCean(String cean) {
        this.cean = cean;
    }

    /**
     * @return the xprod
     */
    public String getXprod() {
        return xprod;
    }

    /**
     * @param xprod the xprod to set
     */
    public void setXprod(String xprod) {
        this.xprod = xprod;
    }

    /**
     * @return the ncm
     */
    public String getNcm() {
        return ncm;
    }

    /**
     * @param ncm the ncm to set
     */
    public void setNcm(String ncm) {
        this.ncm = ncm;
    }

    /**
     * @return the genero
     */
    public String getGenero() {
        return genero;
    }

    /**
     * @param genero the genero to set
     */
    public void setGenero(String genero) {
        this.genero = genero;
    }

    /**
     * @return the cfop
     */
    public String getCfop() {
        return cfop;
    }

    /**
     * @param cfop the cfop to set
     */
    public void setCfop(String cfop) {
        this.cfop = cfop;
    }

    /**
     * @return the ucom
     */
    public String getUcom() {
        return ucom;
    }

    /**
     * @param ucom the ucom to set
     */
    public void setUcom(String ucom) {
        this.ucom = ucom;
    }

    /**
     * @return the qcom
     */
    public String getQcom() {
        return qcom;
    }

    /**
     * @param qcom the qcom to set
     */
    public void setQcom(String qcom) {
        this.qcom = qcom;
    }

    /**
     * @return the vuncom
     */
    public String getVuncom() {
        return vuncom;
    }

    /**
     * @param vuncom the vuncom to set
     */
    public void setVuncom(String vuncom) {
        this.vuncom = vuncom;
    }

    /**
     * @return the vprod
     */
    public String getVprod() {
        return vprod;
    }

    /**
     * @param vprod the vprod to set
     */
    public void setVprod(String vprod) {
        this.vprod = vprod;
    }

    /**
     * @return the ceantrib
     */
    public String getCeantrib() {
        return ceantrib;
    }

    /**
     * @param ceantrib the ceantrib to set
     */
    public void setCeantrib(String ceantrib) {
        this.ceantrib = ceantrib;
    }

    /**
     * @return the utrib
     */
    public String getUtrib() {
        return utrib;
    }

    /**
     * @param utrib the utrib to set
     */
    public void setUtrib(String utrib) {
        this.utrib = utrib;
    }

    /**
     * @return the qtrib
     */
    public String getQtrib() {
        return qtrib;
    }

    /**
     * @param qtrib the qtrib to set
     */
    public void setQtrib(String qtrib) {
        this.qtrib = qtrib;
    }

    /**
     * @return the vuntrib
     */
    public String getVuntrib() {
        return vuntrib;
    }

    /**
     * @param vuntrib the vuntrib to set
     */
    public void setVuntrib(String vuntrib) {
        this.vuntrib = vuntrib;
    }

    /**
     * @return the dadosMedT
     */
    public DadosMedT getDadosMedT() {
        return dadosMedT;
    }

    /**
     * @param dadosMedT the dadosMedT to set
     */
    public void setDadosMedT(DadosMedT dadosMedT) {
        this.dadosMedT = dadosMedT;
    }
    



}
