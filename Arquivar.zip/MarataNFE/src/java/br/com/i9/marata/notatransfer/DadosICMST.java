/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.notatransfer;

/**
 *
 * @author geoleite
 */
public class DadosICMST {
    private String orig;
    private String cst;
    private String modbc;
    private String vbc;
    private String picms;
    private String vicms;
    private String predbc;

    private String vbcst;
    private String vicmsst;
    private String picmsst;
    private String pmvast;
    private String predbcst;
    private String modbcst;


    /**
     * @return the orig
     */
    public String getOrig() {
        return orig;
    }

    /**
     * @param orig the orig to set
     */
    public void setOrig(String orig) {
        this.orig = orig;
    }

    /**
     * @return the cst
     */
    public String getCst() {
        return cst;
    }

    /**
     * @param cst the cst to set
     */
    public void setCst(String cst) {
        this.cst = cst;
    }

    /**
     * @return the vbcst
     */
    public String getVbcst() {
        return vbcst;
    }

    /**
     * @param vbcst the vbcst to set
     */
    public void setVbcst(String vbcst) {
        this.vbcst = vbcst;
    }

    /**
     * @return the vicmsst
     */
    public String getVicmsst() {
        return vicmsst;
    }

    /**
     * @param vicmsst the vicmsst to set
     */
    public void setVicmsst(String vicmsst) {
        this.vicmsst = vicmsst;
    }

    /**
     * @return the modbc
     */
    public String getModbc() {
        return modbc;
    }

    /**
     * @param modbc the modbc to set
     */
    public void setModbc(String modbc) {
        this.modbc = modbc;
    }

    /**
     * @return the vbc
     */
    public String getVbc() {
        return vbc;
    }

    /**
     * @param vbc the vbc to set
     */
    public void setVbc(String vbc) {
        this.vbc = vbc;
    }

    /**
     * @return the picms
     */
    public String getPicms() {
        return picms;
    }

    /**
     * @param picms the picms to set
     */
    public void setPicms(String picms) {
        this.picms = picms;
    }

    /**
     * @return the vicms
     */
    public String getVicms() {
        return vicms;
    }

    /**
     * @param vicms the vicms to set
     */
    public void setVicms(String vicms) {
        this.vicms = vicms;
    }

    /**
     * @return the pmvast
     */
    public String getPmvast() {
        return pmvast;
    }

    /**
     * @param pmvast the pmvast to set
     */
    public void setPmvast(String pmvast) {
        this.pmvast = pmvast;
    }

    /**
     * @return the picmsst
     */
    public String getPicmsst() {
        return picmsst;
    }

    /**
     * @param picmsst the picmsst to set
     */
    public void setPicmsst(String picmsst) {
        this.picmsst = picmsst;
    }

    /**
     * @return the modbcst
     */
    public String getModbcst() {
        return modbcst;
    }

    /**
     * @param modbcst the modbcst to set
     */
    public void setModbcst(String modbcst) {
        this.modbcst = modbcst;
    }

    /**
     * @return the predbc
     */
    public String getPredbc() {
        return predbc;
    }

    /**
     * @param predbc the predbc to set
     */
    public void setPredbc(String predbc) {
        this.predbc = predbc;
    }

    /**
     * @return the predbcst
     */
    public String getPredbcst() {
        return predbcst;
    }

    /**
     * @param predbcst the predbcst to set
     */
    public void setPredbcst(String predbcst) {
        this.predbcst = predbcst;
    }
}
