/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.xml;

/**
 *
 * @author geoleite
 */
public class DadosPisT {
    private String cst;
    private String vbc;
    private String ppis;
    private String vpis;
    private DadosPisntT dadosPisntT;
    

    /**
     * @return the cst
     */
    public String getCst() {
        return cst;
    }

    /**
     * @param cst the cst to set
     */
    public void setCst(String cst) {
        this.cst = cst;
    }

    /**
     * @return the vbc
     */
    public String getVbc() {
        return vbc;
    }

    /**
     * @param vbc the vbc to set
     */
    public void setVbc(String vbc) {
        this.vbc = vbc;
    }

    /**
     * @return the ppis
     */
    public String getPpis() {
        return ppis;
    }

    /**
     * @param ppis the ppis to set
     */
    public void setPpis(String ppis) {
        this.ppis = ppis;
    }

    /**
     * @return the vpis
     */
    public String getVpis() {
        return vpis;
    }

    /**
     * @param vpis the vpis to set
     */
    public void setVpis(String vpis) {
        this.vpis = vpis;
    }

    /**
     * @return the dadosPisntT
     */
    public DadosPisntT getDadosPisntT() {
        return dadosPisntT;
    }

    /**
     * @param dadosPisntT the dadosPisntT to set
     */
    public void setDadosPisntT(DadosPisntT dadosPisntT) {
        this.dadosPisntT = dadosPisntT;
    }
}
