/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.marata.xml;

/**
 *
 * @author geoleite
 */
public class DadosInformacoesAdicionaisT {
    private String infadfisco;
    private String infcpl;

    /**
     * @return the infadfisco
     */
    public String getInfadfisco() {
        return infadfisco;
    }

    /**
     * @param infadfisco the infadfisco to set
     */
    public void setInfadfisco(String infadfisco) {
        this.infadfisco = infadfisco;
    }

    /**
     * @return the infcpl
     */
    public String getInfcpl() {
        return infcpl;
    }

    /**
     * @param infcpl the infcpl to set
     */
    public void setInfcpl(String infcpl) {
        this.infcpl = infcpl;
    }
}
