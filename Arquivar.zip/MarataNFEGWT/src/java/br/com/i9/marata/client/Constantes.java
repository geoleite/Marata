/*
 * Define constantes para acesso aos jsp do servidor
 */

package br.com.i9.marata.client;

/**
 *
 * @author geoleite
 */
public class Constantes {
    public final static String URL = "/maratanfe/";
}

